/**
 * I declare that this code was written by me.
 * I will not copy or allow others to copy my code.
 * I understand that copying code is considered as plagiarism.
 *
 * 21026249, 3 Aug 2022 11:25:53 am
 */

/**
 * @author 21026249
 *
 */
public class Category {
	
	private String name;
	
	public Category (String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}

}
